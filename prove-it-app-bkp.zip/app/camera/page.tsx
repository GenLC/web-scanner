"use client"

import { useState, useRef, useEffect } from "react"
import { ArrowLeft, Star, MoreVertical, ImageIcon, Sun } from "lucide-react"
import Link from "next/link"

export default function CameraPage() {
  const [mode, setMode] = useState<"photo" | "barcode">("photo")
  const [flashOn, setFlashOn] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)
  const [hasPermission, setHasPermission] = useState<boolean | null>(null)

  useEffect(() => {
    // In a real app, this would request camera permission
    // For demo purposes, we'll just simulate it
    setHasPermission(true)
  }, [])

  const toggleFlash = () => {
    setFlashOn(!flashOn)
  }

  if (hasPermission === null) {
    return (
      <div className="flex items-center justify-center h-screen bg-black text-white">
        Requesting camera permission...
      </div>
    )
  }

  if (hasPermission === false) {
    return (
      <div className="flex items-center justify-center h-screen bg-black text-white">
        Camera permission denied. Please enable camera access to use this feature.
      </div>
    )
  }

  return (
    <div className="relative h-screen bg-black">
      {/* Status Bar */}
      <div className="flex justify-between items-center px-4 py-2 text-white">
        <div className="text-lg font-semibold">3:58</div>
        <div className="flex items-center gap-2">
          <div className="h-4 w-4">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M18 9L12 15L6 9" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <div className="flex items-center gap-1">
            <div className="h-3 w-1 bg-gray-300 rounded-t-sm"></div>
            <div className="h-4 w-1 bg-gray-300 rounded-t-sm"></div>
            <div className="h-5 w-1 bg-gray-300 rounded-t-sm"></div>
            <div className="h-6 w-1 bg-gray-300 rounded-t-sm"></div>
          </div>
          <div className="flex items-center gap-1">
            <div className="h-3 w-1 bg-gray-300 rounded-t-sm"></div>
            <div className="h-4 w-1 bg-gray-300 rounded-t-sm"></div>
            <div className="h-5 w-1 bg-gray-300 rounded-t-sm"></div>
            <div className="h-6 w-1 bg-gray-300 rounded-t-sm"></div>
          </div>
          <div className="flex items-center">
            <div className="h-5 w-8 bg-green-500 rounded-full flex items-center justify-end pr-1">
              <div className="h-3 w-3 bg-white rounded-full"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Camera View */}
      <div className="relative h-[calc(100vh-180px)] overflow-hidden">
        {/* Simulated camera view with a placeholder image */}
        <div className="absolute inset-0 bg-gray-800">
          <div className="w-full h-full flex items-center justify-center">
            <img
              src="/placeholder.svg?height=800&width=400"
              alt="Camera view"
              className="w-full h-full object-cover opacity-50"
            />
          </div>
        </div>

        {/* Camera UI Controls */}
        <div className="absolute top-4 left-4">
          <Link href="/">
            <button className="p-2 rounded-full bg-black/30 text-white">
              <ArrowLeft className="h-6 w-6" />
            </button>
          </Link>
        </div>

        <div className="absolute top-4 right-4 flex space-x-4">
          <button className="p-2 rounded-full bg-black/30 text-white">
            <Star className="h-6 w-6" />
          </button>
          <button className="p-2 rounded-full bg-black/30 text-white">
            <MoreVertical className="h-6 w-6" />
          </button>
        </div>

        {/* Scanning Frame */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-[80%] h-[60%] rounded-3xl border-2 border-white/70 overflow-hidden">
            {/* White dot at the bottom of the frame */}
            <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1/2 w-8 h-8 bg-white rounded-full"></div>
          </div>
        </div>
      </div>

      {/* Camera Controls */}
      <div className="absolute bottom-20 left-0 right-0 flex justify-center space-x-4">
        <button className="p-4 rounded-full bg-white">
          <ImageIcon className="h-6 w-6 text-gray-700" />
        </button>

        <div className="flex bg-white rounded-full overflow-hidden">
          <button
            className={`px-6 py-3 ${mode === "photo" ? "bg-green-600 text-white" : "bg-white text-gray-700"}`}
            onClick={() => setMode("photo")}
          >
            Photo
          </button>
          <button
            className={`px-6 py-3 ${mode === "barcode" ? "bg-green-600 text-white" : "bg-white text-gray-700"}`}
            onClick={() => setMode("barcode")}
          >
            Barcode
          </button>
        </div>

        <button className={`p-4 rounded-full ${flashOn ? "bg-green-600" : "bg-white"}`} onClick={toggleFlash}>
          <Sun className={`h-6 w-6 ${flashOn ? "text-white" : "text-gray-700"}`} />
        </button>
      </div>

      {/* Play Button Overlay */}
      <div className="absolute bottom-[70px] left-1/2 transform -translate-x-1/2">
        <div className="w-14 h-14 rounded-full bg-black/50 flex items-center justify-center">
          <div className="w-0 h-0 border-t-[10px] border-t-transparent border-l-[16px] border-l-white border-b-[10px] border-b-transparent ml-1"></div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white pt-4 pb-8 px-6 flex justify-between items-center border-t border-gray-100">
        <Link href="/" className="flex flex-col items-center text-gray-400">
          <div className="text-green-500">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                stroke="currentColor"
                fill="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
          <span className="text-sm font-medium mt-1">Explore</span>
        </Link>
        <div className="bg-green-600 p-4 rounded-full -mt-8 shadow-lg">
          <div className="h-6 w-6 text-white">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M23 19C23 19.5304 22.7893 20.0391 22.4142 20.4142C22.0391 20.7893 21.5304 21 21 21H3C2.46957 21 1.96086 20.7893 1.58579 20.4142C1.21071 20.0391 1 19.5304 1 19V8C1 7.46957 1.21071 6.96086 1.58579 6.58579C1.96086 6.21071 2.46957 6 3 6H7L9 3H15L17 6H21C21.5304 6 22.0391 6.21071 22.4142 6.58579C22.7893 6.96086 23 7.46957 23 8V19Z"
                stroke="white"
                fill="white"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M12 17C14.2091 17 16 15.2091 16 13C16 10.7909 14.2091 9 12 9C9.79086 9 8 10.7909 8 13C8 15.2091 9.79086 17 12 17Z"
                stroke="white"
                fill="white"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
        </div>
        <Link href="/history" className="flex flex-col items-center text-gray-400">
          <div className="h-6 w-6">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M12 6V12L16 14"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
          <span className="text-sm font-medium mt-1">History</span>
        </Link>
      </div>
    </div>
  )
}

